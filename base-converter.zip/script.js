// שם: [הכנס את שמך כאן], ת"ז: [הכנס ת"ז כאן]

const fromButtons = document.querySelectorAll('#from-buttons button');
const toButtons = document.querySelectorAll('#to-buttons button');
const input = document.getElementById('inputNumber');
const result = document.getElementById('result');
const convertBtn = document.getElementById('convertBtn');

let fromBase = null;
let toBase = null;

function selectBase(buttons, baseType) {
  buttons.forEach(btn => {
    btn.classList.remove('selected');
    if (btn.dataset.base === baseType.toString()) {
      btn.classList.add('selected');
    }
  });
  return baseType;
}

fromButtons.forEach(button => {
  button.addEventListener('click', () => {
    fromBase = selectBase(fromButtons, parseInt(button.dataset.base));
  });
});

toButtons.forEach(button => {
  button.addEventListener('click', () => {
    toBase = selectBase(toButtons, parseInt(button.dataset.base));
  });
});

function isValidNumber(inputStr, base) {
  const patterns = {
    2: /^[01]+$/i,
    8: /^[0-7]+$/i,
    10: /^\d+$/,
    16: /^[0-9a-f]+$/i
  };
  return patterns[base]?.test(inputStr);
}

convertBtn.addEventListener('click', () => {
  const inputVal = input.value.trim();

  if (!fromBase || !toBase) {
    alert('Please select both source and target bases.');
    return;
  }

  if (!isValidNumber(inputVal, fromBase)) {
    alert(`Invalid number for base ${fromBase}`);
    return;
  }

  const decimalValue = parseInt(inputVal, fromBase);
  const converted = decimalValue.toString(toBase).toUpperCase();
  result.textContent = `Result: (${fromBase}) ${inputVal} = (${toBase}) ${converted}`;
  input.value = '';
});